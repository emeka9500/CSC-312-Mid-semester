#include <iostream>
#include <stdlib.h>

// Node structure for the stack
struct Node {
  float data;
  Node* next;
};

// Push function
void push(Node** head, float data) {
  // Allocate memory for a new node
  Node* newNode = (Node*)malloc(sizeof(Node));

  // Check for allocation failure
  if (!newNode) {
    std::cerr << "Memory allocation failed!" << std::endl;
    return;
  }

  // Store data in the new node
  newNode->data = data;

  // Push the new node onto the stack
  newNode->next = *head;
  *head = newNode;
}

int main() {
  // Initialize an empty stack
  Node* head = NULL;

  // Push some data onto the stack
  push(&head, 1.23f);
  push(&head, 4.56f);
  push(&head, 7.89f);

  // Print the contents of the stack
  while (head) {
    std::cout << head->data << " ";
    head = head->next;
  }
  std::cout << std::endl;

  return 0;
}
