#include<iostream>
#include<stack>
#include<string>

bool isPalindrome(std::string str) {
    std::stack<char> stack;

    for (char c : str) {
        if (c != ' ') {
            stack.push(tolower(c));
        }
    }

    for (char c : str) {
        if (c != ' ') {
            if (stack.top() != tolower(c)) {
                return false;
            }
            stack.pop();
        }
    }

    return true;
}

int main() {
    std::string str;
    std::cout << "Enter a string: ";
    std::getline(std::cin, str);

    if (isPalindrome(str)) {
        std::cout << "The string is a palindrome.\n";
    } else {
        std::cout << "The string is not a palindrome.\n";
    }

    return 0;
}
